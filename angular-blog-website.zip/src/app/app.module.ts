import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {HttpClientModule} from '@angular/common/http';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomePageComponent } from './pages/home-page/home-page.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { AboutPageComponent } from './pages/about-page/about-page.component';
import { FeaturesComponent } from './pages/features/features.component';
import { TravelComponent } from './pages/travel/travel.component';
import { FashionComponent } from './pages/fashion/fashion.component';
import { MusicComponent } from './pages/music/music.component';
import { ContactComponent } from './pages/contact/contact.component';
import { FeedComponent } from './pages/feed/feed.component';
import { SinglePageComponent } from './pages/single-page/single-page.component';
import { HeaderBannerComponent } from './header-banner/header-banner.component';
import { RightSidebarComponent } from './right-sidebar/right-sidebar.component';
import { BreadcrumbComponent } from './breadcrumb/breadcrumb.component';
import { DemoComponent } from './demo/demo.component';



@NgModule({
  declarations: [
    AppComponent,
    HomePageComponent,
    HeaderComponent,
    FooterComponent,
    AboutPageComponent,
    FeaturesComponent,
    TravelComponent,
    FashionComponent,
    MusicComponent,
    ContactComponent,
    FeedComponent,
    SinglePageComponent,
    HeaderBannerComponent,
    RightSidebarComponent,
    BreadcrumbComponent,
    DemoComponent
    
   
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
