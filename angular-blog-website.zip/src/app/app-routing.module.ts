import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { HomePageComponent } from './pages/home-page/home-page.component';
import { AboutPageComponent } from './pages/about-page/about-page.component';
import { FeaturesComponent } from './pages/features/features.component';
import { TravelComponent } from './pages/travel/travel.component';
import { FashionComponent } from './pages/fashion/fashion.component';
import { MusicComponent } from './pages/music/music.component';
import { ContactComponent } from './pages/contact/contact.component';
import { SinglePageComponent } from './pages/single-page/single-page.component';

const routes: Routes = [
  { path: '', component: HomePageComponent },
  { path: 'home', component: HomePageComponent },
  { path: 'about', component: AboutPageComponent },
  { path: 'features', component: FeaturesComponent },
  { path: 'travel', component: TravelComponent },
  { path: 'fashion', component: FashionComponent },
  { path: 'music', component: MusicComponent },
  { path: 'contact', component: ContactComponent },
  { path: 'singlePage/:id', component: SinglePageComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
