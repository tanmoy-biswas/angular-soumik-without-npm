import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {environment} from '../../environments/environment'
@Injectable({
  providedIn: 'root'
})
export class HttpRequestService {
  protected API_URL = environment.api_url;
  constructor(protected http: HttpClient) {
   }

  _get(action_url){
      return this.http.get(`${this.API_URL}/${action_url}`);
   }

  post(){
    }
  put(){
  }
  delete(){
  }

}
