import { Component, OnInit } from '@angular/core';
import {HttpRequestService} from '../../service/http-request.service';


@Component({
  selector: 'app-about-page',
  templateUrl: './about-page.component.html',
  styleUrls: ['./about-page.component.css']
})
export class AboutPageComponent implements OnInit {

  public all_user : any = [];
  public breadLink  : any = [
    {name:'Home', url:'#'},
    {name:'About Page', url:'#'    }
  ];

  constructor(
    protected Http: HttpRequestService,
    ) {  }

  ngOnInit() {
    this.get_users();
  }

  get_users(){
    this.Http._get('users').subscribe((Responce) => {
    this.all_user = Responce;
      //console.table(this.all_user);
    })
  }


}
