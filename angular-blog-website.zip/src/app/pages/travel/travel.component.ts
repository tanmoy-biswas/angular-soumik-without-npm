import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-travel',
  templateUrl: './travel.component.html',
  styleUrls: ['./travel.component.css']
})
export class TravelComponent implements OnInit {
  public breadLink  : any = [
    {name:'Home', url:'#'},
    {name:'Travel Page', url:'#'    }
  ];
  constructor() { }

  ngOnInit() {
  }

}
