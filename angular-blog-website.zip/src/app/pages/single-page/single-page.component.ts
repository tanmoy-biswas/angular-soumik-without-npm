import { Component, OnInit } from '@angular/core';
import { HttpRequestService } from '../../service/http-request.service';
import { ActivatedRoute} from '@angular/router';

@Component({
  selector: 'app-single-page',
  templateUrl: './single-page.component.html',
  styleUrls: ['./single-page.component.css']
})
export class SinglePageComponent implements OnInit {

  public userId     : number;
  public userPost   : any = {};
  public userDetails: any = {};
  public breadLink  : any = [
    {name:'Home', url:'/home'},
    {name:'Single Page', url:'#'    }
  ];
  constructor( 
    protected http: HttpRequestService,
    protected protected_route : ActivatedRoute
    ) { }

    getParameter(){
      let routeParam = this.protected_route.snapshot.params;
      this.userId = routeParam.id;
      //console.log(this.userId);
    }

    user_post(){
      this.http._get(`posts?userId=${this.userId}`).subscribe( (Responce)=>{
        this.userPost = Responce;
        console.log(this.userPost);
      })
    }

    user_details(){
      this.http._get(`users?id=${this.userId}`).subscribe( (Responce)=>{
        this.userDetails = Responce;
        console.log(this.userDetails);
      })
    }

  ngOnInit() {
    this.getParameter();
    this.user_post();
    this.user_details();
  }

}
