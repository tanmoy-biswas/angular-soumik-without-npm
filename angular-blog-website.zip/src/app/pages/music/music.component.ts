import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-music',
  templateUrl: './music.component.html',
  styleUrls: ['./music.component.css']
})
  export class MusicComponent implements OnInit {
  
  public breadLink  : any = [
    {name:'Home', url:'#'},
    {name:'Music Page', url:'#'    }
  ];
  constructor() { }

  ngOnInit() {
  }

}
