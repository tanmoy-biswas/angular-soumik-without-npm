import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-features',
  templateUrl: './features.component.html',
  styleUrls: ['./features.component.css']
})
export class FeaturesComponent implements OnInit {
  
  public breadLink  : any = [
    {name:'Home', url:'#'},
    {name:'Feature Page', url:'#'    }
  ];

  constructor() { }

  ngOnInit() {
  }

}
