import { Component, OnInit } from '@angular/core';
import {HttpRequestService} from '../service/http-request.service';


@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {

  public allPost      : any = [];
  public searchData   : any = [];
  public posts        : any = [];
  public allUsers     : any = [];
  public user_id      : any;
  public user_details : any={};
  public brdCrumbs    : any = [
    {name : 'Home',url:'#'},
    {name : 'Post',url:'#'},
    {name : 'How to train your dragon',url:'#'},
  ]


  constructor( 
    protected http : HttpRequestService,
  ) { }

  getChieldData(event){
    console.log(event)
  }


  ngOnInit() {
    //this.getPosts();
    this.getUsers()
  }
  // getPosts(){
  //   this.http._get('posts').subscribe((Response)=>{
  //     this.allPost = Response;
  //     console.log(this.allPost);
  //   })
  // }


 	getUsers(){
		this.http._get('users').subscribe((Response)=>{
			this.allUsers = Response;
			//console.log( this.allUsers);
   		 })
  	}
    
  	getUserPosts(Instance){

    console.log(Instance.control);  
	 	let formData = Instance.value;
    let user_id  = formData.user_id
     

    	this.http._get(`posts?userId=${user_id}`).subscribe((Response)=>{
     		//console.log(Response);
      })
      
      this.http._get(`users/${this.user_id}`).subscribe((Response)=>{
        this.user_details = Response;
        //console.log(this.user_details);
      })
  }

	
	// getUserData(){
	// 	this.http._get(`users/${this.user_id}`).subscribe((Response)=>{
  //     this.user_details = Response;
  //     console.log(Response);
  //   })
	// }

  

}
