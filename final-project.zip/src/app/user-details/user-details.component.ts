import { Component, OnInit } from '@angular/core';
import { ActivatedRoute} from '@angular/router';
import { HttpRequestService } from '../service/http-request.service';

@Component({
  selector: 'app-user-details',
  templateUrl: './user-details.component.html',
  styleUrls: ['./user-details.component.css']
})
export class UserDetailsComponent implements OnInit {

  public user : any ={}
  public user_id: number;
  public user_posts : any = {}
  constructor(
    protected activeRoute   : ActivatedRoute,
    protected http : HttpRequestService,
  ) { }

  protected getParames(){
    let route_params = this.activeRoute.snapshot.params;
    console.table(route_params);
    this.user_id = route_params.id;
    //console.log(this.user_id);
	
	}

  ngOnInit() {
    this.getParames();
    this.userData();
  }

  userData(){
    this.http._get(`posts/?userId=${this.user_id}`).subscribe((Response)=>{
    this.user_posts = Response;
    console.log(this.user_posts);
    })


    
  }
}
