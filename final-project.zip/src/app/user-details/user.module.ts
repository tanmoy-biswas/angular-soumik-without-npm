import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { UserRoutingModule } from './user-routing.module';
import { UserDetailsComponent } from '../user-details/user-details.component';
import { HeroAreaComponent } from '../hero-area/hero-area.component';
import { PanelComponent } from '../panel/panel.component';


@NgModule({
  declarations: [UserDetailsComponent,HeroAreaComponent,PanelComponent],
  imports: [
    CommonModule,
    UserRoutingModule
  ],
  exports:[
    UserDetailsComponent
  ]
})
export class UserModule { }
