import { Component, OnInit,Input,Output,EventEmitter } from '@angular/core';

@Component({
  selector: 'app-common',
  templateUrl: './common.component.html',
  styleUrls: ['./common.component.css'],
  //inputs : ['message']
})
export class CommonComponent implements OnInit {

  @Input() message:string = 'Kichu data nai / empty data';
  @Output() emitPass = new EventEmitter();

  constructor() { }

  ngOnInit() {
    //console.table(this.message)
  }

  passUrl(b){
    this.emitPass.emit(b);
  }

}
