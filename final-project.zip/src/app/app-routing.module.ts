import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { IndexComponent } from './index/index.component';
import { MenuPageComponent } from './menu-page/menu-page.component';
import { BlogPageComponent } from './blog-page/blog-page.component';
import { GalleryPageComponent } from './gallery-page/gallery-page.component';
import { FunctionPageComponent } from './function-page/function-page.component';
import { ContactPageComponent } from './contact-page/contact-page.component';
import { SearchComponent } from './search/search.component';

const routes: Routes = [
  { path: '', component: IndexComponent },
  { path: 'menu', component: MenuPageComponent,canActivate:[]},
  { path: 'blog', component: BlogPageComponent },
  { path: 'gallery', component: GalleryPageComponent },
  { path: 'function', component: FunctionPageComponent },
  { path: 'contact-us', component: ContactPageComponent },
  { path: 'search', component: SearchComponent },
  { path: 'user-details', loadChildren:'./user-details/user.module#UserModule'},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
