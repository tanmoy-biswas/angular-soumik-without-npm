import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ng-heroArea',
  templateUrl: './hero-area.component.html',
  styleUrls: ['./hero-area.component.css']
})
export class HeroAreaComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
