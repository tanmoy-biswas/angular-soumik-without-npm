import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {HttpClientModule} from '@angular/common/http';
import { FormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { IndexComponent } from './index/index.component';
import { FooterComponent } from './footer/footer.component';
import { MenuPageComponent } from './menu-page/menu-page.component';
import { BlogPageComponent } from './blog-page/blog-page.component';
import { GalleryPageComponent } from './gallery-page/gallery-page.component';
import { FunctionPageComponent } from './function-page/function-page.component';
import { ContactPageComponent } from './contact-page/contact-page.component';
import { SearchComponent } from './search/search.component';

import { CommonComponent } from './common/common.component';


@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    IndexComponent,
    FooterComponent,
    MenuPageComponent,
    BlogPageComponent,
    GalleryPageComponent,
    FunctionPageComponent,
    ContactPageComponent,
    SearchComponent,
    CommonComponent,
   ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
