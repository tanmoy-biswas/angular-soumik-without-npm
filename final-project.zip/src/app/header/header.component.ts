import { Component, OnInit } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {throwError} from 'rxjs';
import {map,catchError,retry} from 'rxjs/operators';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {


  public posts:any = [];
  constructor(protected http: HttpClient) { }

  ngOnInit() {
    // let data = this.http.get('https://jsonplaceholder.typicode.com/posts').pipe(map())


    //   data.subscribe((r)=>{
    //     console.log(r)
    //     this.posts = r
    //   })
  }

}
