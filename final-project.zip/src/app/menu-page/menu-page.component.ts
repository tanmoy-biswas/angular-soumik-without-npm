import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-menu-page',
  templateUrl: './menu-page.component.html',
  styleUrls: ['./menu-page.component.css']
})
export class MenuPageComponent implements OnInit {
  public brdCrumbs : any = [
    {name : 'Home',url:'#'},
    {name : 'Menu',url:'#'},
    
  ]

  constructor() { }

  ngOnInit() {
    
  }

}
