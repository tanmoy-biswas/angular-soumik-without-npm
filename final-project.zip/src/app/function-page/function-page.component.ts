import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-function-page',
  templateUrl: './function-page.component.html',
  styleUrls: ['./function-page.component.css']
})
export class FunctionPageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
